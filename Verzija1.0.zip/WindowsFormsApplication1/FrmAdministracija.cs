﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class FrmAdministracija : Form
    {
        
        
        
        public FrmAdministracija()
        {
            InitializeComponent();
        }

        private void Administracija_FormClosing(object sender, FormClosingEventArgs e)
        {
            System.Windows.Forms.Application.Exit();
        }

        private void btnNazad_Click(object sender, EventArgs e)
        {
            FrmPocetna frmPocetna = new FrmPocetna();
            frmPocetna.Show();
            this.Hide();
        }

        private void btnAzurirajSmer_Click(object sender, EventArgs e)
        {
            FrmSmer frmSmer = new FrmSmer();
            frmSmer.Show();
            this.Hide();
        }

        private void btnAzurirajStudenta_Click(object sender, EventArgs e)
        {
            FrmStudent frmStudent = new FrmStudent();
            frmStudent.Show();
            this.Hide();
        }

        private void btnAzurirajPredmet_Click(object sender, EventArgs e)
        {
            FrmPredmet frmPredmet = new FrmPredmet();
            frmPredmet.Show();
            this.Hide();
        }

        private void btnPrikaziListu_Click(object sender, EventArgs e)
        {
            FrmIzborna frmIzborna = new FrmIzborna();
            frmIzborna.Show();
            this.Hide();
        }

        private void FrmAdministracija_Load(object sender, EventArgs e)
        {
            if (!File.Exists("smerovi.bin"))
            {
                btnAzurirajStudenta.Enabled = false;
                btnPrikaziListu.Enabled = false;
            }
            else
            {
                btnAzurirajStudenta.Enabled = true;
                btnPrikaziListu.Enabled = true;
            }
            if (!File.Exists("studenti.bin"))
            {
                btnAzurirajPredmet.Enabled = false;
                btnPrikaziListu.Enabled = false;
            }
            else
            {
                btnAzurirajPredmet.Enabled = true;
                btnPrikaziListu.Enabled = true;
            }
        }
    }
}
