﻿namespace WindowsFormsApplication1
{
    partial class FrmIzborna
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnNazad = new System.Windows.Forms.Button();
            this.lbListaPredmeta = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // btnNazad
            // 
            this.btnNazad.Location = new System.Drawing.Point(12, 451);
            this.btnNazad.Name = "btnNazad";
            this.btnNazad.Size = new System.Drawing.Size(192, 63);
            this.btnNazad.TabIndex = 0;
            this.btnNazad.Text = "NAZAD";
            this.btnNazad.UseVisualStyleBackColor = true;
            this.btnNazad.Click += new System.EventHandler(this.btnNazad_Click);
            // 
            // lbListaPredmeta
            // 
            this.lbListaPredmeta.FormattingEnabled = true;
            this.lbListaPredmeta.Location = new System.Drawing.Point(12, 13);
            this.lbListaPredmeta.Name = "lbListaPredmeta";
            this.lbListaPredmeta.Size = new System.Drawing.Size(1132, 433);
            this.lbListaPredmeta.TabIndex = 1;
            // 
            // FrmIzborna
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1156, 526);
            this.Controls.Add(this.lbListaPredmeta);
            this.Controls.Add(this.btnNazad);
            this.Name = "FrmIzborna";
            this.Text = "FrmIzborna";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.FrmIzborna_FormClosing);
            this.Load += new System.EventHandler(this.FrmIzborna_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnNazad;
        private System.Windows.Forms.ListBox lbListaPredmeta;
    }
}