﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class FrmStudent : Form
    {
        string putanjaStudent;
        Student lbStudent;
        public FrmStudent()
        {
            InitializeComponent();
            putanjaStudent = "studenti.bin";
        }

        private void FrmStudent_FormClosing(object sender, FormClosingEventArgs e)
        {
            System.Windows.Forms.Application.Exit();
        }

        private void btnUnesiStudenta_Click(object sender, EventArgs e)
        {
            lblUnesi.Visible = true;
            lblAzuriraj.Visible = false;
            lblIzbrisi.Visible = false;
            gbEdit.Visible = true;
            lbIspiStudenta.Visible = true;
            tbIme.Enabled = true;
            tbIme.Text = "";
            tbPrezime.Enabled = true;
            tbPrezime.Text = "";
            tbIndex.Enabled = true;
            tbIndex.Text = "";
            tbJmbg.Enabled = true;
            tbJmbg.Text = "";
            tbTelefon.Enabled = true;
            tbTelefon.Text = "";

            tbIndex.Focus();
            if (File.Exists(putanjaStudent))
            {
                List<Student> listaStudenata = new List<Student>();
                FileStream fsr = File.OpenRead(putanjaStudent);
                BinaryFormatter bf = new BinaryFormatter();
                listaStudenata = bf.Deserialize(fsr) as List<Student>;
                lbIspiStudenta.DataSource = listaStudenata;
                fsr.Dispose();
            }
            
        }

        private void btnAzurirajStudenta_Click(object sender, EventArgs e)
        {
            lblUnesi.Visible = false;
            lblAzuriraj.Visible = true;
            lblIzbrisi.Visible = false;
            gbEdit.Visible = true;
            lbIspiStudenta.Visible = true;
            tbIme.Enabled = true;
            tbPrezime.Enabled = true;
            tbIndex.Enabled = true;
            tbJmbg.Enabled = true;
            tbTelefon.Enabled = true;
            tbIndex.Focus();
            if (File.Exists(putanjaStudent))
            {
                List<Student> listaStudenata = new List<Student>();
                FileStream fsr = File.OpenRead(putanjaStudent);
                BinaryFormatter bf = new BinaryFormatter();
                listaStudenata = bf.Deserialize(fsr) as List<Student>;
                lbIspiStudenta.DataSource = listaStudenata;
                fsr.Dispose();
            }
            else
            {
                MessageBox.Show("EEEJ KUME, PA NEMA STUDENATA ZA AZURIRANJE!");
                btnUnesiStudenta_Click(sender, e);
            }
        }

        private void btnIzbrisiStudenta_Click(object sender, EventArgs e)
        {
            lblUnesi.Visible = false;
            lblAzuriraj.Visible = false;
            lblIzbrisi.Visible = true;
            gbEdit.Visible = true;
            lbIspiStudenta.Visible = true;
            tbIme.Enabled = false;
            tbPrezime.Enabled = false;
            tbIndex.Enabled = false;
            tbJmbg.Enabled = false;
            tbTelefon.Enabled = false;
            tbIndex.Focus();
            if (File.Exists(putanjaStudent))
            {
                List<Student> listaStudenata = new List<Student>();
                FileStream fsr = File.OpenRead(putanjaStudent);
                BinaryFormatter bf = new BinaryFormatter();
                listaStudenata = bf.Deserialize(fsr) as List<Student>;
                lbIspiStudenta.DataSource = listaStudenata;
                fsr.Dispose();
            }
            else
            {
                MessageBox.Show("EEEJ KUME, PA NEMA STUDENATA ZA BRISANJE!");
                btnUnesiStudenta_Click(sender, e);
            }
        }

        private void btnNazad_Click(object sender, EventArgs e)
        {
            FrmAdministracija frmAdministracija = new FrmAdministracija();
            frmAdministracija.Show();
            this.Hide();
        }

        private void btnPotvrdi_Click(object sender, EventArgs e)
        {
            // ========================== UNOS STUDENTA =========================
            if (lblUnesi.Visible == true)
            {
                if (File.Exists(putanjaStudent))
                {
                    List<Student> listaStudenata = new List<Student>();
                    FileStream fsr = File.OpenRead(putanjaStudent);
                    BinaryFormatter bf = new BinaryFormatter();
                    listaStudenata = bf.Deserialize(fsr) as List<Student>;
                    fsr.Dispose();
                    proveriSmerIDodajStudenta(listaStudenata);
                }
                else
                {
                    List<Student> listaStudenata = new List<Student>();
                    proveriSmerIDodajStudenta(listaStudenata);
                }
            }
            // ========================== AZURIRANJE STUDENTA =========================
            else if (lblAzuriraj.Visible == true)
            {
                List<Student> listaStudenata = new List<Student>();
                FileStream fsr = File.OpenRead(putanjaStudent);
                BinaryFormatter bf = new BinaryFormatter();
                listaStudenata = bf.Deserialize(fsr) as List<Student>;
                fsr.Dispose();
                listaStudenata.RemoveAt(lbIspiStudenta.SelectedIndex);
                if (proveriSmerIDodajStudenta(listaStudenata))
                {
                    lbIspiStudenta.DataSource = listaStudenata;
                }
            }
            // ========================== BRISANJE STUDENTA =========================
            else if (lblIzbrisi.Visible == true)
            {
                List<Student> listaStudenata = new List<Student>();
                FileStream fsr = File.OpenRead(putanjaStudent);
                BinaryFormatter bf = new BinaryFormatter();
                listaStudenata = bf.Deserialize(fsr) as List<Student>;
                fsr.Dispose();

                listaStudenata.RemoveAt(lbIspiStudenta.SelectedIndex);

                FileStream fsw = new FileStream(putanjaStudent, FileMode.Create, FileAccess.Write);
                BinaryFormatter bfe = new BinaryFormatter();
                bfe.Serialize(fsw, listaStudenata);
                fsw.Close();
                fsw.Dispose();
                lbIspiStudenta.DataSource = listaStudenata;
            }
        }
        private void dodajStudenta(List<Student> lista, Student student, string komentar)
        {
            lista.Add(student);
            //MessageBox.Show(komentar);
            tbIme.Clear();
            tbPrezime.Clear();
            tbTelefon.Clear();
            tbJmbg.Clear();
            tbIndex.Clear();
            tbIme.Focus();
            FileStream fsw = new FileStream(putanjaStudent, FileMode.Create, FileAccess.Write);
            BinaryFormatter bf = new BinaryFormatter();
            bf.Serialize(fsw, lista);
            fsw.Close();
            fsw.Dispose();
            lbIspiStudenta.DataSource = lista;
        }
        // ========================= DODAVANJE STUDENTA ================================
        private bool proveriSmerIDodajStudenta(List<Student> listaStudenata)
        {
            bool dobarIndex = false;
            bool dobarJmbg = false;
            for (int i = 0; i < tbIndex.TextLength; i++)
            {
                if (tbIndex.Text[i].Equals('-'))
                {
                    dobarIndex = true;
                }
            }
            if (tbJmbg.TextLength == 13)
            {
                dobarJmbg = true;
            }
            if (dobarIndex)
            {
                // provera imena
                string ime = tbIme.Text;
                if (!jesiKrsten(ime, "ime"))
                {
                    tbIme.Focus();
                    return false;
                }
                // provera prezimena
                string prezime = tbPrezime.Text;
                if (!jesiKrsten(prezime, "prezime"))
                {
                    tbPrezime.Focus();
                    return false;
                }
                if (dobarJmbg)
                {
                    // provera JMBG-a
                    string jmbg = tbJmbg.Text;
                    if (!Regex.IsMatch(jmbg, @"^[0-9]+$"))
                    {
                        MessageBox.Show("Unesi krstene brojeve za JMBG kume!");
                        tbJmbg.Clear();
                        tbJmbg.Focus();
                        return false;
                    }
                    string telefon = tbTelefon.Text;
                    if (!Regex.IsMatch(telefon, @"^[0-9]+$"))
                    {
                        MessageBox.Show("Unesi krstene brojeve za telefon kume!");
                        tbTelefon.Clear();
                        tbTelefon.Focus();
                        return false;
                    }
                
                    string input = tbIndex.Text.ToUpper();
                    int index = input.IndexOf("-");
                    if (index > 0)
                    {
                        input = input.Substring(0, index);
                    }
                    string datumRodjenja = "";
                    for (int i = 0; i < 7; i++)
                    {
                        datumRodjenja += tbJmbg.Text[i];
                    }
                    if (proveraRodjenja(datumRodjenja))
                    {
                        List<Smer> deserijalizovanaLista = new List<Smer>();
                        FileStream fsr = File.OpenRead("smerovi.bin");
                        BinaryFormatter bf = new BinaryFormatter();
                        deserijalizovanaLista = bf.Deserialize(fsr) as List<Smer>;
                        fsr.Dispose();
                        Smer postojeciSmer = new Smer();
                        if (lblAzuriraj.Visible == false)
                        {
                            foreach (Student item in listaStudenata)
                            {
                                if (item.Indeks.ToString().Equals(tbIndex.Text))
                                {
                                    MessageBox.Show("Kume ovaj gi indeks vec postoji, probaj z drugi...");
                                    return false;
                                }
                                if (item.Jmbg.ToString().Equals(jmbg))
                                {
                                    MessageBox.Show("Kume ovaj gi JMBG vec postoji, probaj z drugi...");
                                    return false;
                                }
                                if (item.Telefon.ToString().Equals(telefon))
                                {
                                    MessageBox.Show("Kume ovaj gi telefon vec postoji, probaj z drugi...");
                                    return false;
                                }
                            }
                        }
                        bool isti = false;
                        foreach (Smer item in deserijalizovanaLista)
                        {
                            if (item.NazivSmera.ToString().Equals(input))
                            {
                                postojeciSmer = item;
                                isti = true;
                                break;
                            }
                        }
                        if (isti)
                        {
                            Student noviStudent = new Student(tbIme.Text, tbPrezime.Text, tbJmbg.Text, datumRodjenja, tbIndex.Text.ToUpper(), tbTelefon.Text, postojeciSmer);
                            dodajStudenta(listaStudenata, noviStudent, "Novi student je uspesno dodat!");
                            return true;
                        }
                        else
                        {
                            MessageBox.Show("Ne postoji dati smer!");
                            tbIndex.Focus();
                            return false;
                        }
                    }
                    else
                    {
                        MessageBox.Show("Niste uneli dobar JMBG, molimo vas da unesete tacne podatke!");
                        tbJmbg.Focus();
                        return false;
                    }
                }
                else
                {
                    MessageBox.Show("Niste uneli dobar JMBG, postarajte se da ima 13 karaktera.");
                    tbJmbg.Focus();
                    return false;
                }
            }
            else
            {
                MessageBox.Show("Unesi indeks kume i postaraj se da ima crticu (-)");
                tbIndex.Focus();
                return false;
            }
        }
        // ============================================= PROVERA DATUMA RODJENJA =====================================
        private bool proveraRodjenja(string datumRodjenja)
        {
            string danRodjenja = "", mesecRodjenja = "", godinaRodjenja = "1";
            for (int i = 0; i < 2; i++)
            {
                danRodjenja += datumRodjenja[i];
            }
            for (int i = 2; i < 4; i++)
            {
                mesecRodjenja += datumRodjenja[i];
            }
            for (int i = 4; i < 7; i++)
            {
                godinaRodjenja += datumRodjenja[i];
            }

            int dan, mesec, godina;
            int.TryParse(danRodjenja, out dan);
            int.TryParse(mesecRodjenja, out mesec);
            int.TryParse(godinaRodjenja, out godina);

            if (godina > 1950)
            {
                if (mesec < 13 && mesec > 0)
                {
                    if (mesec == 2)
                    {
                        if (dan < 29 && dan > 0)
                        {
                            return true;
                        }
                        else
                        {
                            return false;
                        }
                    }
                    if (dan < 32 && dan > 0)
                    {
                        return true;
                    }
                }
            }
            return false;
        }

        private bool jesiKrsten(string tekst, string komentar)
        {
            if (!Regex.IsMatch(tekst, @"^[a-zA-Z]+$"))
            {
                MessageBox.Show("Unesi krstena slova za " + komentar + " kume!");
                tbJmbg.Clear();
                tbJmbg.Focus();
                return false;
            }
            return true;
        }

        private void lbIspiStudenta_SelectedIndexChanged(object sender, EventArgs e)
        {
            lbStudent = lbIspiStudenta.SelectedItem as Student;
            if (lblAzuriraj.Visible == true)
            {
                tbIndex.Text = lbStudent.Indeks.ToString();
                tbIme.Text = lbStudent.Ime.ToString();
                tbPrezime.Text = lbStudent.Prezime.ToString();
                tbJmbg.Text = lbStudent.Jmbg.ToString();
                tbTelefon.Text = lbStudent.Telefon.ToString();
            }
        }
    }
}
