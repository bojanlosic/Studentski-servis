﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class FrmIzborna : Form
    {
        public FrmIzborna()
        {
            InitializeComponent();
        }

        private void FrmIzborna_FormClosing(object sender, FormClosingEventArgs e)
        {
            System.Windows.Forms.Application.Exit();
        }

        private void btnNazad_Click(object sender, EventArgs e)
        {
            FrmAdministracija frmAdministracija = new FrmAdministracija();
            frmAdministracija.Show();
            this.Hide();
        }

        private void FrmIzborna_Load(object sender, EventArgs e)
        {
            string fajlEkstenzija = ".bin";
            if (File.Exists("studenti.bin"))
            {
                List<Student> listaStudenata = new List<Student>();
                BinaryFormatter bf = new BinaryFormatter();
                FileStream fs = File.OpenRead("studenti.bin");
                listaStudenata = bf.Deserialize(fs) as List<Student>;
                fs.Dispose();
                fs.Close();

                string[] indeksiStudenata = new string[listaStudenata.Count];

                for (int i = 0; i < indeksiStudenata.Length; i++)
                {
                    string temp = listaStudenata[i].Indeks.ToString();
                    temp = temp.Replace("-", "").Replace("/", "");
                    indeksiStudenata[i] = temp;
                    string pomocni = "";
                    if (File.Exists(temp + fajlEkstenzija))
                    {
                        List<Predmet> listaPredmeta = new List<Predmet>();
                        fs = File.OpenRead(temp + fajlEkstenzija);
                        listaPredmeta = bf.Deserialize(fs) as List<Predmet>;
                        fs.Dispose();
                        fs.Close();
                        pomocni = listaStudenata[i].Indeks.ToString();
                        for (int j = 0; j < listaPredmeta.Count; j++)
                        {
                            pomocni += " " + listaPredmeta[j].Naziv.ToString();
                        }
                    }
                    lbListaPredmeta.Items.Add(pomocni);
                }
            }
            else
            {
                MessageBox.Show("Studenti jos uvek nisu prijavili nijednu listu.");
            }
            
        }
    }
}
